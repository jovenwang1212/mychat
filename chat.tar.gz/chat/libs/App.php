<?php

namespace Libs;

use \Exception;
use \Closure;

/**
 * App 
 *
 * container
 * event
 * 
 */
class App 
{
	use Event, Container;
}