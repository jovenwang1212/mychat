<?php
class Pipe2 {
	private $username;
	public function __construct() {
	}
}

echo Pipe2::class;