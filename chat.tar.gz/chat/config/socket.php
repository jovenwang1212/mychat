<?php

return array(
    'worker_num' => 4,
    'task_worker_num' => 8,
    'daemonize'=>true,
    'max_request' => 10000,
    'dispatch_mode' => 2,
    'debug_mode'=> 1,
);