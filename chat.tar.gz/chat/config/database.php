<?php

/**
 * db_host 	服务器地址
 * db_name 	数据库名
 * db_user 	用户名
 * db_pwd 	密码
 * db_port 	端口
 */

return array(
	    'db_host' =>  '127.0.0.1',
	    'db_name'=>  'd_customer_service',
	    'db_user'=>  'root',
	    'db_pwd'=>  'root',
	    'db_port' =>  '3306',
	    'db_pre'=>""
	);